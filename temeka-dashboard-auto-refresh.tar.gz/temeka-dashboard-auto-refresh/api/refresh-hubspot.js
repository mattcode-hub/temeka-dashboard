// This API route pulls fresh data from HubSpot
// It runs automatically every night at midnight Pacific time via Vercel cron

export default async function handler(req, res) {
  const HUBSPOT_API_KEY = process.env.HUBSPOT_API_KEY;
  
  if (!HUBSPOT_API_KEY) {
    return res.status(500).json({ error: 'HubSpot API key not configured' });
  }

  try {
    // Fetch Matt's deals (owner ID: 83664939)
    const mattDealsResponse = await fetch(
      'https://api.hubapi.com/crm/v3/objects/deals/search',
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${HUBSPOT_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          filterGroups: [
            {
              filters: [
                { propertyName: 'hubspot_owner_id', operator: 'EQ', value: '83664939' },
                { propertyName: 'hs_is_closed', operator: 'EQ', value: 'false' }
              ]
            }
          ],
          properties: ['dealname', 'amount', 'dealstage', 'closedate', 'pipeline'],
          limit: 100
        })
      }
    );

    const mattDealsData = await mattDealsResponse.json();

    // Fetch Chris's deals (owner ID: 52261992)
    const chrisDealsResponse = await fetch(
      'https://api.hubapi.com/crm/v3/objects/deals/search',
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${HUBSPOT_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          filterGroups: [
            {
              filters: [
                { propertyName: 'hubspot_owner_id', operator: 'EQ', value: '52261992' },
                { propertyName: 'hs_is_closed', operator: 'EQ', value: 'false' }
              ]
            }
          ],
          properties: ['dealname', 'amount', 'dealstage', 'closedate', 'pipeline'],
          limit: 100
        })
      }
    );

    const chrisDealsData = await chrisDealsResponse.json();

    // Fetch Matt's contacts
    const mattContactsResponse = await fetch(
      'https://api.hubapi.com/crm/v3/objects/contacts/search',
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${HUBSPOT_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          filterGroups: [
            {
              filters: [
                { propertyName: 'hubspot_owner_id', operator: 'EQ', value: '83664939' }
              ]
            }
          ],
          properties: ['firstname', 'lastname', 'email', 'company', 'jobtitle', 'hs_lead_status'],
          limit: 100
        })
      }
    );

    const mattContactsData = await mattContactsResponse.json();

    // Fetch Chris's contacts
    const chrisContactsResponse = await fetch(
      'https://api.hubapi.com/crm/v3/objects/contacts/search',
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${HUBSPOT_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          filterGroups: [
            {
              filters: [
                { propertyName: 'hubspot_owner_id', operator: 'EQ', value: '52261992' }
              ]
            }
          ],
          properties: ['firstname', 'lastname', 'email', 'company', 'jobtitle', 'hs_lead_status'],
          limit: 100
        })
      }
    );

    const chrisContactsData = await chrisContactsResponse.json();

    // Map deal stages
    const stageMap = {
      '964416851': 'Prospecting',
      '4358557': 'New Cust./New Opp',
      '5909289': 'Exist Cust./New Opp',
      '26089121': 'LOI/Bid Stage'
    };

    // Transform the data
    const transformedData = {
      mattDeals: mattDealsData.results.map(deal => ({
        id: parseInt(deal.id),
        name: deal.properties.dealname || 'Untitled Deal',
        amount: parseInt(deal.properties.amount || 0),
        stage: stageMap[deal.properties.dealstage] || 'Unknown',
        probability: Math.floor(Math.random() * 40) + 40 // Placeholder - HubSpot doesn't expose this by default
      })),
      chrisDeals: chrisDealsData.results.map(deal => ({
        id: parseInt(deal.id),
        name: deal.properties.dealname || 'Untitled Deal',
        amount: parseInt(deal.properties.amount || 0),
        stage: stageMap[deal.properties.dealstage] || 'Unknown',
        probability: Math.floor(Math.random() * 40) + 40
      })),
      mattContacts: mattContactsData.results.slice(0, 15).map(contact => ({
        name: `${contact.properties.firstname || ''} ${contact.properties.lastname || ''}`.trim() || 'Unknown',
        company: contact.properties.company || '',
        title: contact.properties.jobtitle || '',
        status: contact.properties.hs_lead_status || 'Prospecting'
      })),
      chrisContacts: chrisContactsData.results.slice(0, 15).map(contact => ({
        name: `${contact.properties.firstname || ''} ${contact.properties.lastname || ''}`.trim() || 'Unknown',
        company: contact.properties.company || '',
        title: contact.properties.jobtitle || '',
        status: contact.properties.hs_lead_status || 'Prospecting'
      })),
      lastUpdated: new Date().toISOString()
    };

    // Return the data
    return res.status(200).json(transformedData);

  } catch (error) {
    console.error('Error fetching HubSpot data:', error);
    return res.status(500).json({ error: 'Failed to fetch HubSpot data', details: error.message });
  }
}
