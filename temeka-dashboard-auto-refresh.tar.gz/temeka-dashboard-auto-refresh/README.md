# Temeka Sales Dashboard - Auto-Refresh Version

## Quick Setup Instructions

### Step 1: Upload to Vercel

1. Go to your Vercel dashboard: https://vercel.com/dashboard
2. Click "Add New..." → "Project"
3. Click "Import Third-Party Git Repository"
4. Or simply drag and drop this entire folder into Vercel

### Step 2: Add HubSpot API Key

1. In Vercel, go to your project → Settings → Environment Variables
2. Add a new variable:
   - Name: `HUBSPOT_API_KEY`
   - Value: [Your HubSpot Private App Token]
   - Make sure to check all environments (Production, Preview, Development)
3. Click "Save"

### Step 3: Redeploy

1. Go to Deployments tab
2. Click the "..." menu on the latest deployment
3. Click "Redeploy"

## How It Works

- **Auto-Refresh**: Dashboard pulls fresh HubSpot data every night at midnight Pacific time
- **Timestamp**: Shows "Last Updated" timestamp in the header
- **Live on Load**: When Mike/Paul visit the site, they see the most recent data
- **HubSpot Links**: Every deal has a button to open directly in HubSpot

## Cron Schedule

The dashboard refreshes at:
- **Midnight Pacific Time (8:00 AM UTC)** every day
- Configured in `vercel.json`

## Files Included

- `/api/refresh-hubspot.js` - API route that fetches HubSpot data
- `/pages/index.js` - Dashboard component
- `vercel.json` - Cron job configuration
- `package.json` - Dependencies

## Support

If you need to make changes, reach out to Claude with what you want updated!
